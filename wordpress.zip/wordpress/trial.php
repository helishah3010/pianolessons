<?php
/**
* @package SiteGround
* @subpackage Music_Theme
*/ 

//define('WP_USE_THEMES', true);
require( dirname( __FILE__ ) . '/wp-blog-header.php' );
/** Loads the WordPress Environment and Template */
get_header(); ?>

		<div id="primary" <?php if ( !is_active_sidebar(1) ) : ?> class="fullwidth" <?php endif; ?> >
			<div id="content" role="main">

				<article class='post-39 post type-post status-publish format-standard has-post-thumbnail hentry category-bhajanprayers'>
					<div class='note'></div>
					<header class='entry-header'>
						<h2 class='entry-title'>About</h2>
						</header><!-- .entry-header -->
					<h4>Piano lessons is a site prepared by Helly Shah, a passionate piano player who would like to share her skillsets with public. She is also looking out for enthusiastic people who love music playing on piano.Piano lessons is the platform where passionate piano lovers can share there skills and suggests as well.</h4>

			</div><!-- #content -->
		</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>