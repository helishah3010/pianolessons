<?php
/*
Template Name:My collection 
Description:Collection of my own tunes
*/
require( dirname( __FILE__ ) . '/wp-blog-header.php' );
get_header();

echo "<div id='primary'>
			<div id='content' role='main'>
				<article class='post-39 post type-post status-publish format-standard has-post-thumbnail hentry category-bhajanprayers'>
				<div class='note'></div>			
				<header class='entry-header'>
					<h2 class='entry-title'>Bollywood Music</h2>
					</header><!-- .entry-header -->
					
					<a href='' title='Click to see notes'><li>
					<h4>Pehla Nasha</h4>
					</li></a>
					</br>
					<audio controls>
						<source src='humko mann.mp3' type='audio/mpeg'>
						Your browser does not support the audio element.
					</audio>
					
					</br>
					<a href='' ><li>
					<h4>Khamoshiyaan</h4>
					</li></a>
					</br>
					<a href='' ><li>
					<h4>Pehla Nasha</h4>
					</li></a>
			</div>
		</div>
		";
get_sidebar();
get_footer();



?>